'use strict';

var Rss = {};