Sokoban

Sokoban (warehouse keeper) is a type of transport puzzle, in which the player pushes boxes or crates around in a warehouse, trying to get them to storage locations.

Playable here: http://ereses7.github.com/sokoban/
